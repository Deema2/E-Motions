package com.example.demo;
import processing.core.*; 


import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


/**
 *
 * @author manoj.bardhan
 *
 */
@Controller
@EnableAutoConfiguration
public class ThreeDController extends PApplet{
	
	
	// An array of objects
	Oscillator[] oscillators = new Oscillator[10];

	public void setup()  {  
	  size(1400,600);  
	  smooth();  
	  // Initialize all objects
	  for (int i = 0; i < oscillators.length; i++) {
	    oscillators[i] = new Oscillator();
	  }
	  background(20);  
	}  

	public void draw() {    
	  rectMode(CORNER);
	  noStroke();
	  fill(45,10);
	  rect(0,0,width,height);
	  // Run all objects
	  for (int i = 0; i < oscillators.length; i++) {
	    oscillators[i].oscillate();
	    oscillators[i].display();
	  }
	}  


	float m = 20;
	float e = 1;





	class Oscillator {  

	  PVector angle;
	  PVector velocity;
	  PVector amplitude;
	 

	 
	  Oscillator() {  
	    angle = new PVector();
	    velocity = new PVector(random(-0.01*e, 0.01*e), random(-0.01*e, 0.01*e));
	    amplitude = new PVector(random(m,(width*m)/26), random(m,(height*m)/16));
	  }  

	  private float random(double d, double e) {
		// TODO Auto-generated method stub
		return (float) Math.random();
	}

	void oscillate() {
	    angle.add(velocity);
	  }  

	  void display() {  

	    float x = sin(angle.x)*amplitude.x;
	    float y = sin(angle.y)*amplitude.y;

	    pushMatrix();
	    translate(width/2, height/2);
	    stroke((0),(x-y),150-(1/(y*y*2)));
	    strokeWeight(2);
	    fill(80,255);
	    line((2*(x-y)), (2/(y-x)), x, y);
	    ellipse(x, y, 10, 10);  
	    popMatrix();
	  }
	}  


		static public void main(String[] args) {
		      PApplet.main("ThreeDController");
		  }	
			@RequestMapping("/plot3d/{text_classification}")
			@ResponseBody
				public String sayHello() {
					PApplet.main("ThreeDController");
				return "Success";
			}
		}