package com.example.demo;
import processing.core.*; 


import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


/**
 *
 * @author manoj.bardhan
 *
 */
@Controller
@EnableAutoConfiguration
public class HelloWorldController extends PApplet{

	
	
@RequestMapping("/hello")
@ResponseBody
public String sayHello() {
PApplet.main("HelloWorldController");
return "Hello World";
}
}