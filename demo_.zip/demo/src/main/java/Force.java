//package aiart;
import processing.core.*; 
//import processing.data.*; 
//import processing.event.*; 
//import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 



public class Force extends PApplet {


Mover[] movers = new Mover[10];

public void setup() {
  
  randomSeed(1);
  
  for (int i = 0; i < movers.length; i++) {
    movers[i] = new Mover(random(1, 4), random(width), 0);
  }
 
  System.out.print("Debug from here .. ");
  
}


public void draw() {
  background(255);

  for (int i = 0; i < movers.length; i++) {

    PVector wind = new PVector(0.01f, 0);
    PVector gravity = new PVector(0, 0.1f*movers[i].mass);

    float c = 0.05f;
    PVector friction = movers[i].velocity.get();
    friction.mult(-1); 
    friction.normalize();
    friction.mult(c);

    movers[i].applyForce(friction);
    movers[i].applyForce(wind);
    movers[i].applyForce(gravity);

    movers[i].update();
    movers[i].display();
    movers[i].checkEdges();
  }
}
class Mover {
	
	

  PVector location;
  PVector velocity;
  PVector acceleration;
  float mass;

  Mover(float m, float x , float y) {
    mass = m;
    location = new PVector(x,y);
    velocity = new PVector(0,0);
    acceleration = new PVector(0,0);
  }
  
  public void applyForce(PVector force) {
    PVector f = PVector.div(force,mass);
    acceleration.add(f);
  }
  
  public void update() {
    velocity.add(acceleration);
    location.add(velocity);
    acceleration.mult(0);
  }

  public void display() {
    stroke(0);
    strokeWeight(2);
    fill(0,127);
    ellipse(location.x,location.y,mass*16,mass*16);
  }

  public void checkEdges() {

    if (location.x > width) {
      location.x = width;
      velocity.x *= -1;
    } else if (location.x < 0) {
      location.x = 0;
      velocity.x *= -1;
    }

    if (location.y > height) {
      velocity.y *= -1;
      location.y = height;
    }

  }

}
  
public void settings() {  size(383, 200);  smooth(); }
  

static public void main(String[] args) {
//    String[] appletArgs = new String[] { "Force" };
//    if (passedArgs != null) {
//      PApplet.main(concat(appletArgs, passedArgs));
//    } else {
      PApplet.main("Force");
//    }
  }
}
